<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<style>
body {
background-color:#33aaff;
color:white;
margin:0px;
padding:75% 25px 0px 25px;
text-align:center;
} 
</style>


<h4>Sorry for the inconvenience. this app closed with some resource issues!</h4>
