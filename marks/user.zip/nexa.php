<?php
$img='encrypted.png';
$im = imagecreatefrompng($img);
imageflip($im,IMG_FLIP_BOTH);
imagepng($im,$img);
imagedestroy($im);
$im = imagecreatefrompng($img);
$wid=imagesx($im);
$hei=imagesy($im);
$w=$wid/2; $h=$hei/2;
$img1= imagecreatetruecolor($w,$h);
$img2= imagecreatetruecolor($w,$h); 
$img3= imagecreatetruecolor($w,$h);
$img4= imagecreatetruecolor($w,$h); 
imagecopy($img1,$im,0,0,0,0,$w,$h); 
imagecopy($img2,$im,0,0,$w,0,$w,$h);
imagecopy($img3,$im, 0,0,0,$h,$w,$h);
imagecopy($img4,$im, 0,0,$w,$h,$w,$h);
imagedestroy($im);
$src = imagecreatefrompng($img);
imageflip($img1,IMG_FLIP_BOTH);
imagecopy($src,$img1,0,0,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img1);
imagedestroy($src);
$src = imagecreatefrompng($img);
imageflip($img2,IMG_FLIP_BOTH);
imagecopy($src,$img2,$w,0,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img2);
imagedestroy($src);
$src = imagecreatefrompng($img);
imageflip($img3, IMG_FLIP_BOTH);
imagecopy($src,$img3,0,$h,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img3);
imagedestroy($src);
$src = imagecreatefrompng($img);
imageflip($img4,IMG_FLIP_BOTH);
imagecopy($src,$img4,$w,$h,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img4);
imagedestroy($src);
$im = imagecreatefrompng($img);
$data=getimagesize($img);
$wid=$data[0]; $hei=$data[1];
$p=$q=$r=0; $str="";
function rgb2hex($rgb) {
$str=$res="";
$arr[0]=dechex($rgb['red']);
$arr[1]=dechex($rgb['green']);
$arr[2]=dechex($rgb['blue']);
for($x=0;$x<3;$x++){
$num=$arr[$x];
$str="$num";
if(strlen($str)<10 && $num<10){
$res.="0".$str;}
else { $res.=$str; }} 
return $res;
}
for($p=0;$p<$wid;$p++){
for($q=0;$q<$hei;$q++){
$index=imagecolorat($im,$p,$q);
$rgb=imagecolorsforindex($im,$index);
$num=rgb2hex($rgb);
$num=preg_replace('/^0+/',"",$num);
$num=(int)$num;
if($num!=0){
$str.=sprintf("%c",$num); }
} }
echo $str;
?>