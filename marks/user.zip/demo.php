<?php
$xmlDoc = newDOMDocument();
$xmlDoc->load("cse-data.xml");
$x = $xmlDoc->documentElement;
print_r($x->childNodes);
?>