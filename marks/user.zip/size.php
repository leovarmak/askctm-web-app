<?php
$str=fopen('http://codecanyon.net','r');
$arr=[];
for($x=0;$x<strlen($str);$x++){
$arr[$x]=ord($str[$x]); }
$size=count($arr);
$num=sqrt($size);
if(strpos($num,".")){
preg_match('/\d{0,}[.]/',"$num",$str1);
$left=preg_replace('/[.]/',"",$str1[0]);
preg_match('/[.]\d{1}/',"$num",$str2);
$right=preg_replace('/[.]/',"",$str2[0]);
if($right>=5){$wid=$hei=$left+1;
}else{$wid=$left+1;$hei=$left+1;}
}else{$wid=$hei=$num;}
echo "<br/>@".$size."<br/>".$wid."   ". $hei; 
$im = imagecreatetruecolor($hei,$wid);
$transparent=imagecolorallocatealpha($im,0,0,0,127);
/* imagecolortransparent($im,$transparent); */
$bg=imagecolorat($im,0,0);
imagecolorset($im,$bg,0,0,0);
$p=$q=$r=0;
function hex2rgb($hex) {
$r = hexdec(substr($hex,0,2));
$g = hexdec(substr($hex,2,2));
$b = hexdec(substr($hex,4,2));
$rgb = array('red' => $r, 'green' => $g, 'blue' => $b);
return $rgb; }
function zeros($num) {
$x=strlen($num);
for($y=0;$y<=6;$y++){
if($x==$y) {
$str="";
for($z=0;$z<6-$x;$z++) {
$str.="0"; } } }
return $str.$num;
}
for($p=0; $p<$wid;$p++)
{
    for($q=0; $q<$hei;$q++)
     {
$num=$arr[$r];
$len=strlen("$num");
if($len==6) {
$rgb=hex2rgb("$num");
} else {
$num=zeros("$num");
$rgb=hex2rgb("$num"); }
$a=$rgb['red']; $b=$rgb['green']; $c=$rgb['blue'];
$color= imagecolorallocate($im,$a,$b,$c);
imagesetpixel($im,$p,$q,$color); $r++;
      }
}
$img='encrypted.png';
if(file_exists($img)) {
unlink($img); }
imagepng($im,$img);
imagedestroy($im);
$im = imagecreatefrompng($img);
$wid=imagesx($im);
$hei=imagesy($im);
$w=$wid/2; $h=$hei/2;
$img1= imagecreatetruecolor($w,$h);
$img2= imagecreatetruecolor($w,$h); 
$img3= imagecreatetruecolor($w,$h);
$img4= imagecreatetruecolor($w,$h); 
imagecopy($img1,$im,0,0,0,0,$w,$h); 
imagecopy($img2,$im,0,0,$w,0,$w,$h);
imagecopy($img3,$im, 0,0,0,$h,$w,$h);
imagecopy($img4,$im, 0,0,$w,$h,$w,$h);
imagedestroy($im);
$src = imagecreatefrompng($img);
imageflip($img1,IMG_FLIP_BOTH);
imagecopy($src,$img1,0,0,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img1);
imagedestroy($src);
$src = imagecreatefrompng($img);
imageflip($img2,IMG_FLIP_BOTH);
imagecopy($src,$img2,$w,0,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img2);
imagedestroy($src);
$src = imagecreatefrompng($img);
imageflip($img3, IMG_FLIP_BOTH);
imagecopy($src,$img3,0,$h,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img3);
imagedestroy($src);
$src = imagecreatefrompng($img);
imageflip($img4,IMG_FLIP_BOTH);
imagecopy($src,$img4,$w,$h,0,0,$w,$h);
imagepng($src,$img);
imagedestroy($img4);
imagedestroy($src);
$src = imagecreatefrompng($img);
imageflip($src,IMG_FLIP_BOTH);
imagepng($src,$img);
imagedestroy($src);
?>