<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<style>
body,iframe { margin:0; }
</style>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3801.2761495109326!2d82.978914914125!3d17.68441019882707!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a39713000000001%3A0xdaa0830e1a1ff85f!2sAsk+College+Of+Technology+%26+Management.!5e0!3m2!1sen!2sin!4v1489339352833" style="width:100%;height:100%;" frameborder="0" style="border:0" allowfullscreen></iframe>