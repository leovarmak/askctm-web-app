<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<style>body,iframe{margin:0;}
#loader{
width:100%;
height:100%;
display:block;
z-index:9999;
top:0;
left:0;
position:absolute;
background-color:#fff;
background-image: url("../files/loader.gif");
background-size:45px 45px;
background-position: center;
background-repeat: no-repeat;
} 
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(window).on("load",function () {
   $("#loader").fadeOut("slow");
});
</script>

<div id="loader"></div>

<div class="fb-page ws-fb-like-box" data-href="https://www.facebook.com/1596428783986756" 
						data-tabs="timeline" 
						data-width="400" 
						data-height="800"
						data-small-header="false" 
						data-adapt-container-width="true" 
						data-hide-cover="false"
						data-show-facepile="true">
						<div class="fb-xfbml-parse-ignore">
							<blockquote cite="https://www.facebook.com/1596428783986756">
								<a href="https://www.facebook.com/1596428783986756">Facebook</a>
							</blockquote>
						</div>
					 </div> <div id="fb-root"></div>
					 <script>(function(d, s, id) {
					  var js, fjs = d.getElementsByTagName(s)[0];
					  if (d.getElementById(id)) return;
					  js = d.createElement(s); js.id = id;
					  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.6";
					  fjs.parentNode.insertBefore(js, fjs);
					}(document, 'script', 'facebook-jssdk'));</script>