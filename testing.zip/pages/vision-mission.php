<meta name="viewport" content="width=device-width, initial-scale=1, user-sclable=no">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
p {
font-size:15px;
line-height:28px;
}

</style>
<div class="w3-container w3-margin w3-center w3-padding-small">
<h6><span class="w3-tag w3-blue w3-center">VISION</span>
</h6>
<p>
To create and nurture competent Engineers and managers who would be enterprise leaders in all parts of the world with aims of reaching the skies and touching the stars and yet feet firmly planted on the ground-good human beings steeped in ethical and moral values.
</p>
<br>
<h6><span class="w3-tag w3-green w3-center">MISSION</span>
</h6>
<p>
ASK College of Technology and Management is committed to providing a positive, professional and conducive learning environment where all students are inspired to achieve their potential and strive for excellence in a global society as dignified professionals with the cooperation of all stakeholders.</p>
<br>
<h6><span class="w3-tag w3-deep-orange  w3-center">OBJECTIVES</span>
</h6>
<div style="text-align:left;">
<ul>
  <li> To provide for instruction and training in such branches of learning as it may deem fit.</li>

<li> To provide for research and for the advancement of and dissemination of knowledge.</li>

<li> To undertake extramural studies, extension programmes and field outreach activities to contribute to the    development of society.</li>

<li> To acquire existing or establish new academic institutions/departments/centres.</li>

<li> To do all such other acts and things as may be necessary or desirable to further the objectives of the    Institute.</li>
</ol>
</div>
</div>