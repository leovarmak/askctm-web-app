<head>
<meta name="viewport" content="width=device-width, initial-scale=1, user-sclable=no">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<base href="../images/faces/management/" />
<style>

body{
background-color:#f3f9fe;
margin:0;
} 
h4{
} 
h4:after{
content:"";
width:50%;
height:2px;
display:inline-block;
background-color:#62768c;
margin-top:8px;
} 

.w3-container {
padding:10px 15px !important;
border-radius:2px  !important;
color:#fff !important;
} 
p{
font-family:inherit;
margin:15px 0px;
line-height:25px;
font-size:14px;
} 

img {
width:100px;
height:auto;
border:2px solid #eee;
margin:15px;
border-radius:5px;
} 

b{
float:right;
margin:0px 10px 10px 0px;
} 
</style>

<script>
setTimeout(function(){ 
var elem = document. createElement("link"); elem.setAttribute("rel","stylesheet"); 
elem.setAttribute("href","http://apps.askctm.in/files/font-loader.css"); 
document.head.appendChild(elem); },1000);
</script>




<div class="w3-container w3-animate-zoom w3-amber w3-margin w3-center w3-card-2 w3-padding">
<h4>Chairman's Message</h4>
<img src="chairman.jpg" />

<p><strong>“</strong> The Anakapalle Merchant’s Association is serving the people through education and health care from 1945 onwards.It has taken another step by starting ASK College of Technology and Management. <strong>”</strong></p>
<p><b>- K. Lakshmi Narayana Rao</b></p>
</div>

<div class="w3-container w3-teal w3-margin w3-center w3-card-2 w3-padding">
<h4>Vice Chairman's Message</h4>
<img src="vicechairman.jpg" />

<p><strong>“</strong> Dear Students, I am pleased to go down with you a few lines about the college A.M.A.K.S & I.K.R. College of Technology and Management and the Trust by which the college is established. <strong>”</strong></p>
<p><b></b></p>
</div>

<div class="w3-container w3-animate-zoom w3-red w3-margin w3-center w3-card-2 w3-padding">
<h4>President's Message</h4>
<img src="president.jpg" />

<p><strong>“</strong> To bring the best of education to the rural people with the best equipment and teaching to bring out the best out of the student to make the students aware that he/she is no less equipped to deal with the world than his/ her counterpart in a metropolis. <strong>”</strong></p>
<p><b>- Thamanna Raghu Babu</b></p>
</div>



<div class="w3-container w3-deep-orange w3-margin w3-center w3-card-2 w3-padding">
<h4>Correspondent's Message</h4>
<img src="correspondent.jpg" />

<p><strong>“</strong> We are proud that our institution with well-qualified and committed faculty and hi-tech infrastructure enable our students to achieve and further their career in the challenging world. With this note of confidence, I warmly welcome our freshers and am sure that will enjoy the high quality of education imparted in the various disciplines and upon that foundation, build a great future for themselves. <strong>”</strong></p>
<p><b>- Bala Subrahmanyam</b></p>
</div>


<div class="w3-container w3-blue-grey w3-margin w3-center w3-card-2 w3-padding">
<h4>Principal's Message</h4>
<img src="principal.jpg" />
<p><strong>“</strong> My aim is to create place for our institute in the Galaxy of World Renowned Institute of Higher Learning. He contributes his humble share to provide excellent education, training to the students through state of the art technology and methods by a team of well commited faculty. <strong>”</strong></p>
<p><b>- Dr. Vasanta Rajendra Prasad</b></p>
</div>

