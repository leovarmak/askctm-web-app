<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
small{
line-height:28px;
} 
</style>
<div class="w3-responsive">
<table class="w3-table-all">
<thead>
<tr class="w3-green">
<th>Course Name</th>
<th>Intake</th>
<th>Fee (P.A)</th>
</tr>
</thead>

<tr>
<td>CSE</td>
<td>60</td>
<td>&#8377; 35,000/-</td>
</tr>

<tr>
<td>ECE</td>
<td>60</td>
<td>&#8377; 35,000/-</td>
</tr>

<tr>
<td>MECH</td>
<td>60</td>
<td>&#8377; 35,000/-</td>
</tr>

<tr>
<td>CIVIL</td>
<td>60</td>
<td>&#8377; 35,000/-</td>
</tr>

<tr>
<td colspan=4>
<small>
# No extra fee for Management Seats. <br>
# No Building fund & hidden fees. <br>
<b>Eligibility</b> : ECET/EAMCET <br>
<b>Hostel Fee: &#8377;20,000(P.A) for OC candidates </b>
</small>
</td>
</tr>
</table>
</div>