<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
body {
margin:0;
} 
img{
width:100%;
margin:10px 0px;
}
p,li{
margin:10px 10px;
line-height:22px;
} 
</style>

<base href="../images/placements/" />


<img src="1.jpg" />
<img src="2.jpg" />
<img src="3.jpg" />
<img src="4.jpg" />
<img src="placements-1.jpg" />
<img src="placements-2.jpg" />
<img src="placements-3.jpg" />
<img src="5.jpg" />
<img src="6.jpg" />
<br>
<p>
&nbsp;&nbsp;<strong><h4>Placements</h4></strong>

<ul>

<li>On February 11, 2018, ICICI company conducted Campus Drive at ASK College of Technology & Management. Around 350 Students of different colleges attended and 60 students are selected for this company.</li>

<li>On March 24, 2017, POLARIS, HGS, SERCO, EIDIKO companies conducted Campus Drive at ASK College of Technology & Management and 80 students are placed in these companies.</li>

<li>On January 4, 2017, HCL Technologies Team addressing students about remarkable growth of IT Sector. Around 400 Students of different colleges attended.HCL team selected 52 students in this interview.</li>

<li>On December 18, 2016 at ASK College of Technology & Management.15 students are placed in these companies. Visited Companies are ALCHEMY DECORS, LEARNING PEPPERS, NATIVE DIVA.</li>



</ul>
</p>
<br><br><br><br><br>

