<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<style>
@font-face { 
font-family: prn;
src: url('../files/proxima_nova.ttf'); 
}
*{
font-family: 'prn', aerial;
letter-spacing:1px;
}

body {
margin:4px;
background:#f3f2f7;
}
a{
text-decoration:none;
margin:0;}

.w3-col{
padding:10px 0px;
text-align:center !important;
border:4px solid #f2f2f2 !important;
outline-offset:-5px;
border-radius:8px !important;
} 

img{
width:50%;
} 

h3{
margin:0;
} 


</style>
<body>

<div class="w3-row">

<div class="w3-col s12 w3-white w3-animate-zoom">
<h3 class="w3-text-blue">COURSES OFFERED</h3>
</div>

<a href="courses-pages/cse.html" target="_parent">
<div class="w3-col s6 w3-white w3-animate-zoom">
<img src="../images/cse-icon.png">
<h3 class="w3-text-red">CSE</h3>
</div>
</a>

<a href="courses-pages/ece.html" target="_parent">
<div class="w3-col s6 w3-white w3-animate-zoom">
<img src="../images/ece-icon.png">
<h3 class="w3-text-green">ECE</h3>
</div>
</a>

<a href="courses-pages/mech.html" target="_parent">
<div class="w3-col s6 w3-white w3-animate-zoom">
<img src="../images/mech-icon.png">
<h3 class="w3-text-amber">MECH</h3>
</div>
</a>

<a href="courses-pages/civil.html" target="_parent">
<div class="w3-col s6 w3-white w3-animate-zoom">
<img src="../images/civil-icon.png">
<h3 class="w3-text-cyan">CIVIL</h3>
</div>
</a>



</div>
</body>


