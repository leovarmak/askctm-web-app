<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
	<title></title>
</head>
<style>body,iframe{margin:0;}
#loader{
width:100%;
height:100%;
display:block;
z-index:9999;
top:0;
left:0;
position:absolute;
background-color:#fff;
background-image: url("../files/loader.gif");
background-size:45px 45px;
background-position: center;
background-repeat: no-repeat;
} 
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script>
$(window).on("load",function () {
   $("#loader").fadeOut("slow");
});
</script>

<div id="loader"></div>

<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<style>
img {
width:150px;
height:150px;
object-fit:cover;
border-radius:100px;
} 

h4:after{
content:"";
width:40%;
height:2px;
background-color:rgba(255,255,255,.5);
display:block;
margin:10px 30%;

} 
</style>


<base href="../images/" />

<div class="w3-blue-grey w3-container w3-padding-32 w3-center">
    <h4>M. ANIL KUMAR</h4>
<img class="w3-margin" src="developer1.jpg"  />
<center>
<p><small><b>MTech</b>, Cyber Security</small></p>
<p><small>Assistant Professor</small></p>
</center>
</div>

<div class="w3-purple w3-container w3-padding-32 w3-center">
    <h4>K. Karthik Varma</h4>
<img class="w3-margin" src="avatar1.png"  />
<center>
<p><small><b>CSE</b>, 4<sup>th</sup> year</small></p>
<p><small>Android Deveploer</small></p>
</center>
</div>


<div class="w3-green w3-container w3-padding-32 w3-center">
<h4>K. SAI KRISHNA</h4>
<img class="w3-margin" src="avatar3.png" />
<center>
<p><small><b>CSE</b>, 3<sup>rd</sup> year</small></p>
<p><small>Web Deveploer</small></p>
</center>
</div>

<div class="w3-pink w3-container w3-padding-32 w3-center">
<h4>B. SAI SRINIVASRAO</h4>
<img class="w3-margin" src="avatar2.png" />
<center>
<p><small><b>CSE</b>, 3<sup>rd</sup> year</small></p>
<p><small>Data Analyst</small></p>

</center>
</div>

<div class="w3-red w3-container w3-padding-32 w3-center">
<h4>P. LOVARAJU</h4>
<img class="w3-margin" src="avatar1.png" />
<center>
<p><small><b>CSE</b>, 3<sup>rd</sup> year</small></p>
<p><small>DevOps</small></p>
</center>
</div>





<script>
setTimeout(function(){ 
var elem = document. createElement("link"); elem.setAttribute("rel","stylesheet"); 
elem.setAttribute("href","../files/font-loader.css"); 
document.head.appendChild(elem); },100);
</script>



</html>