<style>
table {
    border-collapse: collapse;
}
table td {
    padding:10px;
    text-align:center;
}
.mnx td {
    background :orangered;
    color:white;
    border:1px solid black;
}
</style>
<?php
global $conn;

$servername = "35.229.234.11";
$username = "root";
$password = "05101997";
$database = "marks";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$database", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }


class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 


function table_gen($name,$sem,$conn)
{
    
    echo "<center>".$name."</center><br/>";
    echo "<table>";
    echo "<tr class='mnx'>";

    $stmt = $conn->prepare("show columns from ".$sem); 
    $stmt->execute();

    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
    foreach($stmt->fetchAll() as $k=>$v) { 
        echo "<td>".$v["Field"]."</td>";
    }
    echo "</tr>";
    try {
    $stmt = $conn->prepare("select * from ".$sem." where id='15B41A0502'"); 
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 
    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) { 
        echo $v;
    }
     }
    catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
    }
    echo "</table>";
}


table_gen("1st Year - 1st Sem","1_1",$conn);
echo "<br/><br/>";
table_gen("1st Year - 2nd Sem","1_2",$conn);
echo "<br/><br/>";
table_gen("2nd Year - 1st Sem","2_1",$conn);


?>